"""Normalized CDC log -> replayable warehouse. Python standard library only."""

from __future__ import annotations

import argparse
import hashlib
import json
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def canonical(value: object) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def validate(event: object) -> dict:
    if not isinstance(event, dict):
        raise ValueError("event must be an object")
    required = {"schema_version", "event_id", "position", "entity", "entity_id", "op", "after"}
    if set(event) != required:
        raise ValueError("v1 envelope fields must match the contract")
    if type(event["schema_version"]) is not int or event["schema_version"] != 1:
        raise ValueError("unsupported schema_version")
    for field in ("event_id", "entity_id"):
        if not isinstance(event[field], str) or not event[field].strip():
            raise ValueError(f"{field} must be a nonempty string")
    if type(event["position"]) is not int or not 0 < event["position"] <= 9223372036854775807:
        raise ValueError("position must be a positive signed 64-bit integer")
    if event["entity"] not in ("customer", "order") or event["op"] not in ("r", "c", "u", "d"):
        raise ValueError("unsupported entity or operation")
    row = event["after"]
    if event["op"] == "d":
        if row is not None:
            raise ValueError("delete must have a null after image")
        return event
    if not isinstance(row, dict):
        raise ValueError("non-delete events need a complete after image")
    if event["entity"] == "customer":
        if set(row) != {"segment"} or row["segment"] not in ("standard", "premium"):
            raise ValueError("customer needs a supported segment")
    else:
        if set(row) != {"customer_id", "amount_cents", "status"}:
            raise ValueError("order after image fields must match the contract")
        if not isinstance(row["customer_id"], str) or not row["customer_id"].strip():
            raise ValueError("customer_id must be a nonempty string")
        if (
            type(row["amount_cents"]) is not int
            or not 0 <= row["amount_cents"] <= 9223372036854775807
        ):
            raise ValueError("amount_cents must be a nonnegative signed 64-bit integer")
        if row["status"] not in ("pending", "paid", "cancelled"):
            raise ValueError("unsupported order status")
    return event


class Warehouse:
    def __init__(self, database: str | Path = ":memory:"):
        self.db = sqlite3.connect(database)
        self.db.row_factory = sqlite3.Row
        self.db.executescript((ROOT / "sql/schema.sql").read_text())

    def close(self) -> None:
        self.db.close()

    def ingest(self, events: list, *, fail_before_publish: bool = False) -> dict:
        result = {"accepted": 0, "duplicates": 0, "quarantined": 0}
        # Do not use executescript here: it commits an active transaction implicitly.
        with self.db:
            for raw in events:
                payload = canonical(raw)
                digest = hashlib.sha256(payload.encode()).hexdigest()
                try:
                    event = validate(raw)
                except ValueError as error:
                    self.db.execute(
                        "INSERT OR IGNORE INTO quarantine VALUES (?, ?, ?)",
                        (digest, payload, str(error)),
                    )
                    result["quarantined"] += 1
                    continue
                prior = self.db.execute(
                    "SELECT digest FROM change_log WHERE event_id = ?", (event["event_id"],)
                ).fetchone()
                if prior:
                    if prior["digest"] != digest:
                        raise ValueError(f"event identity conflict: {event['event_id']}")
                    result["duplicates"] += 1
                    continue
                try:
                    self.db.execute(
                        "INSERT INTO change_log VALUES (?, ?, ?, ?, ?, ?, ?)",
                        (
                            event["event_id"],
                            event["position"],
                            event["entity"],
                            event["entity_id"],
                            event["op"],
                            payload,
                            digest,
                        ),
                    )
                except sqlite3.IntegrityError as error:
                    raise ValueError(
                        "source position conflict; repair the normalized log"
                    ) from error
                result["accepted"] += 1
            if fail_before_publish:
                raise RuntimeError("injected failure before publication")
            for statement in (ROOT / "sql/materialize.sql").read_text().split(";"):
                if statement.strip():
                    self.db.execute(statement)
            orphans = self.db.execute(
                "SELECT COUNT(*) FROM orders o LEFT JOIN customers c USING(customer_id) "
                "WHERE c.customer_id IS NULL"
            ).fetchone()[0]
            if orphans:
                raise ValueError("orphan orders; replay with missing customer changes")
        return result

    def report(self) -> dict:
        counts = {
            table: self.db.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
            for table in ("change_log", "customer_history", "customers", "orders", "quarantine")
        }
        return {
            "counts": counts,
            "revenue": [
                dict(row)
                for row in self.db.execute("SELECT * FROM revenue_by_segment ORDER BY segment")
            ],
        }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("demo", "ingest", "report"))
    parser.add_argument("--database", default=":memory:")
    parser.add_argument("--input", type=Path)
    args = parser.parse_args()
    if args.command == "ingest" and args.input is None:
        parser.error("ingest requires --input")
    warehouse = Warehouse(args.database)
    try:
        output = {}
        if args.command != "report":
            source = args.input or ROOT / "data/changes.json"
            events = json.loads(source.read_text())
            if not isinstance(events, list):
                parser.error("input must be a JSON array of normalized change events")
            output["ingestion"] = warehouse.ingest(events)
            if args.command == "demo":
                output["replay"] = warehouse.ingest(events)
        output["warehouse"] = warehouse.report()
        print(json.dumps(output, indent=2))
    finally:
        warehouse.close()


if __name__ == "__main__":
    main()
